package com.javainuse.bank.service;

import com.javainuse.banking.AccountBalanceResponse;
import com.javainuse.banking.AccountBalanceServiceGrpc;
import com.javainuse.banking.AccountRequest;
import com.javainuse.banking.CustomError;

import io.grpc.Metadata;
import io.grpc.Status;
import io.grpc.protobuf.ProtoUtils;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

@GrpcService
public class BankAccountBalanceService extends AccountBalanceServiceGrpc.AccountBalanceServiceImplBase {

	@Override
	public void getAccountBalance(AccountRequest request,
			StreamObserver<com.javainuse.banking.AccountBalanceResponse> responseObserver) {
		
		if ((request.getAccountNumber().equals("account5"))) {
			Metadata metadata = new Metadata();
			Metadata.Key<CustomError> customError = ProtoUtils.keyForProto(CustomError.getDefaultInstance());
			metadata.put(customError, CustomError.newBuilder().setMessage("Database Error- Connection Refused.")
					.setErrorType("CONNECTION_REFUSED").build());
			var statusRuntimeException = Status.NOT_FOUND
					.withDescription("The requested Account Number cannot be found.").asRuntimeException(metadata);
			responseObserver.onError(statusRuntimeException);
			return;
		}

		AccountBalanceResponse empResp = AccountBalanceResponse.newBuilder()
				.setAccountNumber(request.getAccountNumber()).setBalance(100).build();

		// set the response object
		responseObserver.onNext(empResp);

		// mark process is completed
		responseObserver.onCompleted();
	}
}
