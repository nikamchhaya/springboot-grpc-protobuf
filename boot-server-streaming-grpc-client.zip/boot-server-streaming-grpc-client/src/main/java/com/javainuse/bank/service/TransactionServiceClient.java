package com.javainuse.bank.service;

import java.util.concurrent.TimeUnit;

import com.javainuse.banking.AccountRequest;
import com.javainuse.banking.TransactionDetailList;
import com.javainuse.banking.TransactionServiceGrpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

public class TransactionServiceClient {

	private final ManagedChannel channel;
	private final TransactionServiceGrpc.TransactionServiceStub asyncStub;

	public TransactionServiceClient(String host, int port) {
		this(ManagedChannelBuilder.forAddress(host, port).usePlaintext().build());
	}

	public TransactionServiceClient(ManagedChannel channel) {
		this.channel = channel;
		asyncStub = TransactionServiceGrpc.newStub(channel);
	}

	public void streamTransactions(String accountNumber, int durationInDays) {
		AccountRequest request = AccountRequest.newBuilder().setAccountNumber(accountNumber)
				.setDurationInDays(durationInDays).build();

		asyncStub.streamTransactions(request, new StreamObserver<TransactionDetailList>() {
			@Override
			public void onNext(TransactionDetailList transactionDetail) {
				// Handle each incoming TransactionDetail here
				System.out.println("Received transaction detail: " + transactionDetail);
			}

			@Override
			public void onError(Throwable throwable) {
				System.err.println("Error occurred during transaction streaming: " + throwable);
			}

			@Override
			public void onCompleted() {
				System.out.println("Transaction streaming completed");
			}
		});
	}

	public void shutdown() throws InterruptedException {
		channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
	}

}