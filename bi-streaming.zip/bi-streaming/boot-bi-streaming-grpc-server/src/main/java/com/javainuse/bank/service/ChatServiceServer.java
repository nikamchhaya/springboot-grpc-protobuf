package com.javainuse.bank.service;


import com.javainuse.banking.ChatMessage;
import com.javainuse.banking.ChatResponse;
import com.javainuse.banking.ChatServiceGrpc;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

@GrpcService
public class ChatServiceServer extends ChatServiceGrpc.ChatServiceImplBase {

	@Override
	public StreamObserver<ChatMessage> startChat(StreamObserver<ChatResponse> responseObserver) {
		return new ChatStreamObserver(responseObserver);
	}

}