package com.javainuse.bank.service;

import java.util.concurrent.CountDownLatch;

import org.springframework.stereotype.Service;

@Service
public class BankService {

	public void getTransactions() throws InterruptedException {
		TransactionServiceClient client = new TransactionServiceClient("localhost", 8090);
		client.streamTransactions("123456789", 30);
		// Wait indefinitely to receive all transactions. Add a timeout if required.
		new CountDownLatch(1).await();
		client.shutdown();
	}
}
